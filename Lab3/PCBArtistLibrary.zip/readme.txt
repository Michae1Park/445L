Sept 27, 2015, Fall 2015 version

If this is your first installation of the EE345L PCB library
1) Unzip the library file putting it in an easy to find place
2) Start PCB Artist
3) Click the Library tool (big blue book), opens Library manager
4) Select the "Folders" tab
5) Click the "Add..." button
6) Browse to find the directory created in step 1
7) Click OK
8) Move EE345L to the top of the list
9) Close library manager

If this is an update from a previous installation of the EE345L PCB library
1) Unzip the library file putting it in an easy to find place
2) Copy and replace the six libary files into the directory used during the initial installation
Optional steps
3) Start PCB Artist and open any files you are currently working on
4) Execute Tools->UpdateComponents->AllComponents to incorporate possible library changes on

If you want to build new parts or edit parts in this library, I suggest you create a new library. This way, when the EE345L TAs and professors add new stuff to this library, you can upgrade without loosing your edits.
1) Open Library manager
2) Select the "Schematic Symbols" tab, execute "New Lib..."
3) Select the "PCB Symbols" tab, execute "New Lib..."
4) Select the "Components" tab, execute "New Lib..."
You can edit an existing part and save it into your library. 

If it seems to be getting the wrong footprint
1) Click the Library tool (big blue book), opens Library manager
2) Select the "Folders" tab
3) Move EE345L to the top of the list
4) Close library manager

