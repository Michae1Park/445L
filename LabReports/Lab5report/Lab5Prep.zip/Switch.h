//------------Switch_Init------------
// Initialize GPIO Port C bit 4-7 for input
// Input: none
// Output: none
void Switch_Init(void);
