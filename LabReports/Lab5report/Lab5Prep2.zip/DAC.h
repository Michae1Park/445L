#include <stdint.h>

// **************DAC_Out*********************
// DAC output
// Input: 4 bits to output to DAC
void DAC_Out(uint16_t output);

// **************DAC_Init*********************
// Initialize DAC
void DAC_Init(uint16_t data);
