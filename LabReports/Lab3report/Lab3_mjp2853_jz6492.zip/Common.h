// AlarmClockMain.c 
// Michael Park, Jack Zhao
// Date Created: 2/12/2016
// Includes common global variable flags
// Lab Number: 16340
// TA: Mahesh Srinivasan
// Last Revised: 2/15/2016

#include <stdint.h>

extern volatile uint16_t Mode;
extern volatile uint16_t active_In10s;
