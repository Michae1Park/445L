// SetTime.c
// Michael Park, Jack Zhao
// Date Created: 02/10/2016
// class for functions to set time
// Lab Number: 16340
// TA: Mahesh Srinivasan
// Last Revised: 02/15/16

//global: hour, min, alarmflag, displayflag, switchflag(for interrupt)
void ToggleAlarm_Init(void);
void CheckAlarmTrigger(void);
void ToggleAlarmTrigger(void);
void CheckAlarmTime(void);
