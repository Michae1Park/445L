void StopWatch_Init(void);
void DisplayStopwatch(void);

void triggerStopWatch(void);
void endStopWatch(void);


